<?php

session_start();

if (isset($_SESSION["user"])) {
    if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 's') {
        header("location: ../login.php");
    } else {
        $useremail = $_SESSION["user"];
    }
} else {
    header("location: ../login.php");
}

// Import database
include("../connection.php");
$userrow = $database->query("select * from student where semail='$useremail'");
$userfetch = $userrow->fetch_assoc();
$userid = $userfetch["sid"];
$username = $userfetch["sname"];

// PHPMailer namespaces - moved to the top
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/src/Exception.php';
require '../../PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/src/SMTP.php';



if ($_POST) {
    if (isset($_POST["booknow"])) {
        $apponum = $_POST["apponum"];
        $scheduleid = $_POST["scheduleid"];
        $date = $_POST["date"];
        $remarks = isset($_POST["remarks"]) ? $_POST["remarks"] : ''; // Capture remarks
        $counselling_type = isset($_POST["counselling_type"]) ? $_POST["counselling_type"] : ''; // Capture counselling type

        // Insert appointment into the database
        $sql2 = "insert into appointment(sid, apponum, scheduleid, appodate, remarks, counselling_type)
                 values ('$userid', '$apponum', '$scheduleid', '$date', '$remarks', '$counselling_type')";
        $result = $database->query($sql2);

        if ($result) {
            // Fetch counsellor email
            $sqlCounsellor = "SELECT counsellor.cemail, counsellor.cname, schedule.scheduletime 
                                FROM counsellor 
                                INNER JOIN schedule ON counsellor.cid = schedule.cid 
                                WHERE schedule.scheduleid = '$scheduleid'";
            $resultCounsellor = $database->query($sqlCounsellor);

            if ($resultCounsellor->num_rows > 0) {
                $row = $resultCounsellor->fetch_assoc();
                $counsellorEmail = $row["cemail"];
                $counsellorName = $row["cname"];
                $scheduletime=$row["scheduletime"];

                // Send email notification to counsellor
                $mail = new PHPMailer(true);
                try {
                    // Server settings
                    $mail->isSMTP();
                    $mail->Host = 'smtp.sendgrid.net'; // Or your SMTP provider
                    $mail->SMTPAuth = true;
                    $mail->Username = 'apikey'; // Use "apikey" as the username
                    $mail->Password = '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'; // Replace with your SendGrid API key
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;
                
                    // Recipients
                    $mail->setFrom('inozrh@gmail.com', 'UPTM Counselling');
                    $mail->addAddress($counsellorEmail, $counsellorName);

                    // Content
                    $mail->isHTML(true);
                    $mail->Subject = 'New Appointment Booked!';
                    $mail->Body = "Dear $counsellorName,<br><br>" .
                                  "A new appointment has been booked.<br><br>" .
                                  "<b>Appointment Details:</b><br>" .
                                  "- Date: $date<br>" .
                                  "- Time: $scheduletime<br>" .
                                  "- Student Name: $username<br>" .
                                  "- Counselling Type: $counselling_type<br>" .
                                  "- Remarks: $remarks<br><br>" .
                                  "Please check UCAS Website for further details.<br><br>Regards,<br>UCAS";

                    $mail->send();
                    echo "Email notification sent to the counsellor.";


                // Email to student
                 // Clear addresses for sending to the student
                 $mail->clearAddresses();
                $mail->addAddress($useremail,$username);
                $mail->Subject = 'Appointment Booking Confirmation';
                $mail->Body = "Dear $username,<br><br>" .
                              "Your appointment has been successfully booked.<br><br>" .
                              "<b>Appointment Details:</b><br>" .
                              "- Date: $date<br>" .
                              "- Time: $scheduletime<br>" .
                              "- Counsellor Name: $counsellorName<br>" .
                              "- Counselling Type: $counselling_type<br>" .
                              "- Remarks: $remarks<br><br>" .
                              "Please contact us if you have any questions.<br><br>Regards,<br>UPTM Counselling";

                $mail->send();
                echo "Email notification sent to the student.";
            } catch (Exception $e) {
                echo "Email could not be sent. Error: {$mail->ErrorInfo}";
            }
        }
    }

    // Redirect upon successful booking
    header("location: appointment.php?action=booking-added&id=" . $apponum . "&titleget=none");
    exit();
}
}
?>
