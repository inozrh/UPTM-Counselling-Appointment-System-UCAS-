
    <?php
    
    

    //import database
    include("../connection.php");



    if($_POST){
        //print_r($_POST);
        $result= $database->query("select * from webuser");
        $name=$_POST['name'];
        $noid=$_POST['studid'];
        $oldemail=$_POST["oldemail"];
        $code=$_POST['scode'];
        $email=$_POST['email'];
        $tele=$_POST['Tele'];
        $password=$_POST['password'];
        $cpassword=$_POST['cpassword'];
        $id=$_POST['id00'];
        
        if ($password==$cpassword){
            $error='3';
            $aab="select student.sid from student inner join webuser on student.semail=webuser.email where webuser.email='$email';";
            $result= $database->query($aab);
            //$resultqq= $database->query("select * from counsellor where cid='$id';");
            if($result->num_rows==1){
                $id2=$result->fetch_assoc()["sid"];
            }else{
                $id2=$id;
            }
            

            if($id2!=$id){
                $error='1';
                //$resultqq1= $database->query("select * from counsellor where cemail='$email';");
                //$did= $resultqq1->fetch_assoc()["cid"];
                //if($resultqq1->num_rows==1){
                    
            }else{

                //$sql1="insert into counsellor(cemail,cname,cpassword,cnic,ctel,position) values('$email','$name','$password','$nic','$tele',$position);";
                $sql1="update student set semail='$email',sname='$name',spassword='$password',studid='$noid',stel='$tele',scode='$code' where sid=$id ;";
                $database->query($sql1);
                echo $sql1;
                $sql1="update webuser set email='$email' where email='$oldemail' ;";
                $database->query($sql1);
                echo $sql1;
                
                $error= '4';
                
            }
            
        }else{
            $error='2';
        }
    
    
        
        
    }else{
        //header('location: signup.php');
        $error='3';
    }
    

    header("location: settings.php?action=edit&error=".$error."&id=".$id);
    ?>
    
   

</body>
</html>