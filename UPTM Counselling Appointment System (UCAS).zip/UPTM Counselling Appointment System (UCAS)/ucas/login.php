<?php
include("connection.php");
include("audit-logs.php"); // Include the audit logging script

// Start the session
session_start();

$_SESSION["user"] = "";
$_SESSION["usertype"] = "";

// Set the new timezone
date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');

$_SESSION["date"] = $date;

// Generate math CAPTCHA if not already set
if (!isset($_SESSION["captcha_firstNum"]) || !isset($_SESSION["captcha_secondNum"])) {
    $firstNum = rand(1, 10);
    $secondNum = rand(1, 10);
    $_SESSION["captcha_firstNum"] = $firstNum;
    $_SESSION["captcha_secondNum"] = $secondNum;
    $_SESSION["captcha_answer"] = $firstNum + $secondNum;
}

$error = '';

if ($_POST) {
    $email = filter_var($_POST['useremail'], FILTER_SANITIZE_EMAIL); // Sanitize email input
    $password = htmlspecialchars($_POST['userpassword']); // Sanitize password input
    $captcha = $_POST["captcha"]; // Get CAPTCHA input
    
    $error = '<label for="promter" class="form-label"></label>';


    // Validate CAPTCHA
    if ($captcha != $_SESSION["captcha_answer"]) {
        $error = '<label style="color:red;">❌ Incorrect CAPTCHA answer! Try again.</label>';
    } else {
        // Reset CAPTCHA after successful validation
        unset($_SESSION["captcha_firstNum"]);
        unset($_SESSION["captcha_secondNum"]);
        unset($_SESSION["captcha_answer"]);
    
    $result = $database->query("SELECT * FROM webuser WHERE email='$email'");
    if ($result->num_rows == 1) {
        $utype = $result->fetch_assoc()['usertype'];

        if ($utype == 's') {
            $checker = $database->query("SELECT * FROM student WHERE semail='$email'");
            if ($checker->num_rows == 1) {
                $user = $checker->fetch_assoc();
                $hashedPassword = $user['spassword'];
        
                // Securely verify password
                if (password_verify($password, $hashedPassword)) {
                    $_SESSION['user'] = $email;
                    $_SESSION['usertype'] = 's';
        
                    // Log successful login
                    logAudit($email, "Successful Login (Student)", $database);
        
                    header('location: student/index.php');
                } else {
                    $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
                    
                    // Log failed login attempt
                    logAudit($email, "Failed Login Attempt (Invalid Credentials - Student)", $database);
                }
            }
        }
         elseif ($utype == 'a') {
            $checker = $database->query("SELECT * FROM admin WHERE aemail='$email' AND apassword='$password'");
            if ($checker->num_rows == 1) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'a';

                // Log successful login
                logAudit($email, "Successful Login (Admin)", $database);

                header('location: admin/index.php');
            } else {
                $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';

                // Log failed login attempt
                logAudit($email, "Failed Login Attempt (Invalid Credentials - Admin)", $database);
            }
        } 
        elseif ($utype == 'r') {
            $checker = $database->query("SELECT * FROM clerk WHERE remail='$email' AND rpassword='$password'");
            if ($checker->num_rows == 1) {
                $_SESSION['user'] = $email;
                $_SESSION['usertype'] = 'r';

                // Log successful login
                logAudit($email, "Successful Login (Counselling Clerk)", $database);

                header('location: clerk/index.php');
            } else {
                $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';

                // Log failed login attempt
                logAudit($email, "Failed Login Attempt (Invalid Credentials - Counselling Clerk)", $database);
            }
        } elseif ($utype == 'c') {
            $checker = $database->query("SELECT * FROM counsellor WHERE cemail='$email'");
            if ($checker->num_rows == 1) {
                $user = $checker->fetch_assoc();
                $hashedPassword = $user['cpassword'];
        
                // Securely verify password
                if (password_verify($password, $hashedPassword)) {
                    $_SESSION['user'] = $email;
                    $_SESSION['usertype'] = 'c';
        
                    // Log successful login
                    logAudit($email, "Successful Login (Counsellor)", $database);
        
                    header('location: counsellor/index.php');
                    exit();
                } else {
                    $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Wrong credentials: Invalid email or password</label>';
                    
                    // Log failed login attempt
                    logAudit($email, "Failed Login Attempt (Invalid Credentials - Counsellor)", $database);
                }
            }
        }
        
    } else {
        $error = '<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">We can’t find any account for this email.</label>';

        // Log failed login due to unregistered email
        logAudit($email, "Failed Login Attempt (Email Not Registered)", $database);
    }
}
} else {
    $error = '<label for="promter" class="form-label">&nbsp;</label>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/login.css">
    <title>Login</title>
</head>
<body>
    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
            <tr>
                <td><p class="header-text">Welcome Back!</p></td>
            </tr>
            <tr>
                <td><p class="sub-text">Login with your details to continue</p></td>
            </tr>
            <tr>
                <form action="" method="POST">
                    <td class="label-td">
                        <label for="useremail">Email: </label>
                        <input type="email" name="useremail" class="input-text" placeholder="Email Address" required>
                    </td>
            </tr>
            <tr>
                <td class="label-td">
                    <label for="userpassword">Password: </label>
                    <input type="password" name="userpassword" class="input-text" placeholder="Password" required>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <!-- Math CAPTCHA -->
                    <label for="captcha">Solve: <strong><?php echo $_SESSION["captcha_firstNum"]; ?> + <?php echo $_SESSION["captcha_secondNum"]; ?> = ?</strong></label>
                    <input type="text" name="captcha" required>
                </td>
            </tr>
            <tr>
                <td><?php echo $error; ?></td>
            </tr>
            <tr>
                <td>
                    <input type="submit" value="Login" class="login-btn btn-primary btn">
                </td>
            </tr>
            <tr>
                <td style="text-align:center;">
                    <a href="forgot_password.php" class="forgot-password-link">Forgot Password?</a>
                </td>
            </tr>
                </form>
        </table>
    </div>
    </center>
</body>
</html>