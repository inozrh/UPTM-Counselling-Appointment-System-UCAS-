<?php
include("../connection.php");
session_start();

// Ensure counselor is logged in
if (!isset($_SESSION["user"]) || $_SESSION["usertype"] != "c") {
    echo json_encode(["error" => "Unauthorized"]);
    exit;
}

$useremail = $_SESSION["user"];
$userrow = $database->query("SELECT * FROM counsellor WHERE cemail='$useremail'");
$userfetch = $userrow->fetch_assoc();
$userid = $userfetch["cid"];

// Fetch only logged-in counselor's schedule
$query = "SELECT * FROM schedule WHERE cid = '$userid'";
$result = $database->query($query);

$events = [];
while ($row = $result->fetch_assoc()) {
    $events[] = [
        'title' => $row['title'], 
        'start' => $row['scheduledate'] . "T" . $row['scheduletime']
    ];
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($events);
?>
