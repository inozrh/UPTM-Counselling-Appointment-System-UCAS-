<?php

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='c'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    
    // Import PHPMailer namespaces
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../../PHPMailer/src/Exception.php';
require '../../PHPMailer/src/PHPMailer.php';
require '../../PHPMailer/src/SMTP.php';

if ($_GET) {
    // Import database
    include("../connection.php");

    $id = $_GET["id"];

    // Fetch appointment details
    $result001 = $database->query("SELECT appointment.appodate, student.semail, student.sname, 
                                    counsellor.cemail, counsellor.cname, schedule.scheduletime 
                                    FROM appointment
                                    INNER JOIN schedule ON appointment.scheduleid = schedule.scheduleid
                                    INNER JOIN counsellor ON schedule.cid = counsellor.cid
                                    INNER JOIN student ON appointment.sid = student.sid
                                    WHERE appointment.appoid = '$id'");

    if ($result001->num_rows > 0) {
        $row = $result001->fetch_assoc();
        $counsellorEmail = $row["cemail"];
        $counsellorName = $row["cname"];
        $appointmentDate = $row["appodate"];
        $scheduleTime = $row["scheduletime"];
        $studentEmail = $row["semail"];
        $studentName = $row["sname"];

        // Delete the appointment
        $sql = $database->query("DELETE FROM appointment WHERE appoid='$id'");

        if ($sql) {
            // Email notification to counsellor
            $mail = new PHPMailer(true);

            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.sendgrid.net'; // Your SMTP host
                $mail->SMTPAuth = true;
                $mail->Username = 'apikey'; // Use "apikey" as the username
                $mail->Password = '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'; // Replace with your SendGrid API key
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;
            
                // Recipients
                $mail->setFrom('inozrh@gmail.com', 'UPTM Counselling');
                $mail->addAddress($counsellorEmail, $counsellorName);

                // Email content
                $mail->isHTML(true);
                $mail->Subject = 'Appointment Cancellation';
                $mail->Body = "Dear $counsellorName,<br><br>" .
                              "An appointment has been canceled.<br><br>" .
                              "<b>Appointment Details:</b><br>" .
                              "- Date: $appointmentDate<br>" .
                              "- Time: $scheduleTime<br><br>" .
                              "Please login UCAS for more information.<br><br>Regards,<br>UCAS";

                $mail->send();

                // Notify Student
                 // Clear addresses for sending to the student
                 $mail->clearAddresses();
                $mail->addAddress($studentEmail, $studentName);

                $mail->isHTML(true);
                $mail->Subject = 'Appointment Cancellation';
                $mail->Body = "Dear $studentName,<br><br>" .
                              "Your appointment scheduled on $appointmentDate at $scheduleTime has been canceled.<br><br>" .
                              "If you have any questions, please visit UCAS Website.<br><br>Regards,<br>UCAS";

                $mail->send();

                echo "Email notifications sent to both the counsellor and student.";
            } catch (Exception $e) {
                echo "Email could not be sent. Error: {$mail->ErrorInfo}";
            }
        }
    }

    // Redirect to appointment page
    header("location: appointment.php");
}

?>
