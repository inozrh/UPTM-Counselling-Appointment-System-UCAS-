
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';


$mail = new PHPMailer(true);

try {
    // Server settings
    $mail->isSMTP();
    $mail->Host = 'smtp.sendgrid.net';
    $mail->SMTPAuth = true;
    $mail->Username = 'apikey'; // Use "apikey" as the username
    $mail->Password = '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'; // Replace with your SendGrid API key
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    // Recipients
    $mail->setFrom('inozrh@gmail.com', 'Ina');
    $mail->addAddress('nurina2806@gmail.com', 'ina');

    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Test Email via SendGrid SMTP';
    $mail->Body    = '<p>This is a test email sent using SendGrid SMTP with PHPMailer.</p>';

    $mail->send();
    echo 'Email sent successfully!';
} catch (Exception $e) {
    echo "Email could not be sent. Error: {$mail->ErrorInfo}";
}
?>
