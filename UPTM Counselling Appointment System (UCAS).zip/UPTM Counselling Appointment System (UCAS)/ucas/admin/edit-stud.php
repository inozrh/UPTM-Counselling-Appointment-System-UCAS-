<?php
include("../connection.php");
include("../audit-logs.php"); // Include the audit logging script

if ($_POST) {
    $result = $database->query("SELECT * FROM webuser");

    $name = $_POST['name'];
    $noid = $_POST['noid'];
    $code = $_POST['code'];
    $email = $_POST['email'];
    $tele = $_POST['Tele'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $oldemail = $_POST["oldemail"];
    $id = $_POST['id00'];

    if ($password == $cpassword) {
        $error = '3';

        // Fetch current hashed password
        $currentPasswordQuery = $database->query("SELECT spassword FROM student WHERE sid=$id");
        $currentPassword = $currentPasswordQuery->fetch_assoc()['spassword'];

        // Determine whether to hash the new password or keep the existing one
        if (!empty($password) && !password_verify($password, $currentPassword)) {
            // User entered a new password, hash it
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $passwordChanged = true; // Flag for audit logging
        } else {
            // Keep the existing hashed password
            $hashedPassword = $currentPassword;
            $passwordChanged = false;
        }

        // Ensure email change is valid
        $result = $database->query("SELECT student.sid FROM student 
                                    INNER JOIN webuser ON student.semail = webuser.email 
                                    WHERE webuser.email='$email'");

        if ($result->num_rows == 1) {
            $id2 = $result->fetch_assoc()["sid"];
        } else {
            $id2 = $id;
        }

        if ($id2 != $id) {
            $error = '1';
        } else {
            // Update student details safely
            $sql1 = "UPDATE student 
                     SET semail='$email', sname='$name', spassword='$hashedPassword', studid='$noid', stel='$tele', scode='$code' 
                     WHERE sid=$id";
            $database->query($sql1);

            // Update email in webuser table
            $sql2 = "UPDATE webuser SET email='$email' WHERE email='$oldemail'";
            $database->query($sql2);

            // Log the update action
            $logMessage = "Updated student (ID: $id): Data Updated '$name'";
            logAudit($email, $logMessage, $database);

            $error = '4';
        }
    } else {
        $error = '2';
    }
} else {
    $error = '3';
}

// Redirect after update
header("location: student.php?action=edit&error=" . $error . "&id=" . $id);
?>
