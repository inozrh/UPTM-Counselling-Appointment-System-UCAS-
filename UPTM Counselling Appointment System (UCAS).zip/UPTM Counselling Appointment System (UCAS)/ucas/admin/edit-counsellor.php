<?php
// Import database connection
include("../connection.php");
include("../audit-logs.php"); // Adjust path based on location


if ($_POST) {
    $result = $database->query("SELECT * FROM webuser");

    $name = $_POST['name'];
    $nic = $_POST['nic'];
    $oldemail = $_POST["oldemail"];
    $spec = $_POST['position'];
    $email = $_POST['email'];
    $tele = $_POST['Tele'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];
    $id = $_POST['id00'];

    if ($password == $cpassword) {
        $error = '3';

        // Fetch current hashed password
        $currentPasswordQuery = $database->query("SELECT cpassword FROM counsellor WHERE cid=$id");
        $currentPassword = $currentPasswordQuery->fetch_assoc()['cpassword'];

        // Determine whether to hash the new password or keep the existing one
        if (!empty($password) && !password_verify($password, $currentPassword)) {
            // User entered a new password, hash it
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $passwordChanged = true; // Flag for audit logging
        } else {
            // Keep the existing hashed password
            $hashedPassword = $currentPassword;
            $passwordChanged = false;
        }

        // Ensure email change is valid
        $result = $database->query("SELECT counsellor.cid FROM counsellor 
                                    INNER JOIN webuser ON counsellor.cemail = webuser.email 
                                    WHERE webuser.email='$email'");

        if ($result->num_rows == 1) {
            $id2 = $result->fetch_assoc()["cid"];
        } else {
            $id2 = $id;
        }

        if ($id2 != $id) {
            $error = '1';
        } else {
            // Update counsellor details safely
            $sql1 = "UPDATE counsellor 
                     SET cemail='$email', cname='$name', cpassword='$hashedPassword', cnic='$nic', ctel='$tele', position='$spec' 
                     WHERE cid=$id";
            $database->query($sql1);

            // Update email in webuser table
            $sql2 = "UPDATE webuser SET email='$email' WHERE email='$oldemail'";
            $database->query($sql2);

            // Log the update action
            $logMessage = "Updated counsellor (ID: $id): Data Updated '$name'";
            if ($passwordChanged) {
                $logMessage .= ", Password updated";
            }
            logAudit($email, $logMessage, $database);

            $error = '4';
        }
    } else {
        $error = '2';
    }
} else {
    $error = '3';
}

// Redirect after update
header("location: counsellors.php?action=edit&error=" . $error . "&id=" . $id);
?>
