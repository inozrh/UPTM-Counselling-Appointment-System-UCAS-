<?php
    include("../connection.php"); // Ensure this file connects correctly

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $appoid = $_POST["appoid"];
    $status = $_POST["status"];

    if (empty($appoid) || empty($status)) {
        die("Error: Missing appointment ID or status.");
    }

    // Debugging: Print received values
    echo "Updating appointment ID: $appoid to status: $status";

    // Update status in database
    $sql = "UPDATE appointment SET status = '$status' WHERE appoid = '$appoid'";
    
    if ($database->query($sql) === TRUE) {
        header("Location: appointment.php?status_updated=true");
        exit();
    } else {
        echo "Error updating status: " . $database->error;
    }
}
?>
