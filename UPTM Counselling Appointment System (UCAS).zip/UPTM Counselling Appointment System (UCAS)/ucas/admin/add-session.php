<?php

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    
    if($_POST){
        //import database
        include("../connection.php");
        $title=$_POST["title"];
        $cid=$_POST["cid"];
        $date=$_POST["date"];
        $time=$_POST["time"];
        $max_pax = $_POST["max_pax"]; 

        $sql="INSERT INTO schedule (cid, title, scheduledate, scheduletime, max_pax) 
                VALUES ('$cid', '$title', '$date', '$time', '$max_pax');";
        $result= $database->query($sql);
        header("location: schedule.php?action=session-added&title=$title");
        
    }


?>