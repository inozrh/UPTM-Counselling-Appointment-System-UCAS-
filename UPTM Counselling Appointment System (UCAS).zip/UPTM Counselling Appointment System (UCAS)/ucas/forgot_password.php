<?php
session_start();
include("connection.php");
include("audit-logs.php");

// Set PHP timezone correctly
date_default_timezone_set("Asia/Kuala_Lumpur");

// Load PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Debug: Check if email input is received
    //echo "Debug - Email received: " . $email . "<br>";

    // Generate token and expiry time BEFORE using them
    $token = bin2hex(random_bytes(50)); // Generate secure token
    $expiry = date("Y-m-d H:i:s", strtotime("+1 hour")); // Set expiry time

    // Find user's role in webuser table
    $roleQuery = "SELECT usertype FROM webuser WHERE email='$email'";
    $roleResult = $database->query($roleQuery);

    // Debug: Check if role is retrieved
    if ($roleResult && $roleResult->num_rows == 1) {
        $role = $roleResult->fetch_assoc()['usertype'];
        //echo "Debug - Role fetched: " . $role . "<br>";

        // Determine correct table
        $table = "";
        $emailColumn = "";
        if ($role == "s") { $table = "student"; $emailColumn = "semail"; }
        elseif ($role == "c") { $table = "counsellor"; $emailColumn = "cemail"; }

        // Update token only if role is valid
        if ($table != "") {
            $updateQuery = "UPDATE $table SET token='$token', token_expiry='$expiry' WHERE $emailColumn='$email'";
            
            // Debug: Check if the query executes successfully
            if ($database->query($updateQuery)) {
                //echo "Debug - Token updated successfully for " . $table . "<br>";
            } else {
                //echo "Database error: " . $database->error . "<br>";
            }

            // Set up PHPMailer for email sending
            $resetLink = "http://localhost/ucas/reset_password.php?token=$token&role=$role";
            $subject = "Password Reset Request";
            $message = "Dear User,<br><br>Click the link below to reset your password:<br><br>
                        <a href='$resetLink'>$resetLink</a><br><br>Regards,<br>UCAS System";

            try {
                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = "smtp.sendgrid.net"; // Or your SMTP provider
                $mail->SMTPAuth = true;
                $mail->Username = 'apikey'; // Always "apikey" for SendGrid
                $mail->Password = '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'; // Replace with your actual SendGrid API key
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                // Email details
                $mail->setFrom('inozrh@gmail.com', 'UCAS System');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = $subject;
                $mail->Body = $message;

                $mail->send();
                logAudit($email, "Password Reset Requested ($role)", $database);
                $_SESSION['message'] = "Password reset email sent successfully!";
            } catch (Exception $e) {
                $_SESSION['message'] = "Email could not be sent. Error: {$mail->ErrorInfo}";
            }
        } else {
            $_SESSION['message'] = "Invalid role detected!";
        }
    } else {
        $_SESSION['message'] = "Email not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/login.css">
    <title>Forgot Password</title>
</head>
<body>
    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
            <tr>
                <td><p class="header-text">Reset Your Password</p></td>
            </tr>
        <div class="form-body">
            <tr>
                <td><p class="sub-text">Enter your email below to receive a password reset link</p></td>
            </tr>
            <tr>
                <form action="" method="POST">
                <td class="label-td">
                    <label for="email" class="form-label">Email: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="email" name="email" class="input-text" placeholder="Email Address" required>
                </td>
            </tr>
            <tr>
                <td><br><?php echo isset($_SESSION['message']) ? "<p class='error-message'>{$_SESSION['message']}</p>" : ""; ?></td>
            </tr>
            <tr>
                <td>
                    <input type="submit" value="Submit" class="login-btn btn-primary btn">
                </td>
            </tr>
        </div>
                </form>
        </table>
    </div>
    </center>
</body>
</html>