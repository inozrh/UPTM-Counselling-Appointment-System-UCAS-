<?php

    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"])=="" or $_SESSION['usertype']!='r'){
            header("location: ../login.php");
        }

    }else{
        header("location: ../login.php");
    }
    
    
    if($_POST){
        //import database
        include("../connection.php");
        $title=$_POST["title"];
        $cid=$_POST["cid"];
        $date=$_POST["date"];
        $time=$_POST["time"];
        $sql="insert into schedule (cid,title,scheduledate,scheduletime) values ('$cid','$title','$date','$time');";
        $result= $database->query($sql);
        header("location: schedule.php?action=session-added&title=$title");
        
    }


?>