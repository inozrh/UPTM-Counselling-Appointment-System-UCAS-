<?php
session_start();
include("connection.php");
include("audit-logs.php");

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["password"]) && isset($_GET["token"]) && isset($_GET["role"])) {
    $token = $_GET["token"];
    $role = $_GET["role"];
    $newPassword = password_hash($_POST["password"], PASSWORD_DEFAULT);

    // Determine the correct table and password column based on role
    $table = "";
    $passwordColumn = "";
    
    if ($role == "s") { $table = "student"; $passwordColumn = "spassword"; }
    elseif ($role == "c") { $table = "counsellor"; $passwordColumn = "cpassword"; }

    if ($table != "") {
        // Verify the token and check if it's still valid
        $query = "SELECT * FROM student WHERE token='$token' AND token_expiry > NOW()";
        $result = $database->query($query);

        if ($result->num_rows == 1) {
            // Update password and clear token
            $updateQuery = "UPDATE $table SET $passwordColumn='$newPassword', token=NULL, token_expiry=NULL WHERE token='$token'";
            if ($database->query($updateQuery)) {
                $shortToken = substr($token, 0, 8); // Show only the first 8 characters
                logAudit($shortToken, "Password Reset Successful ($role)", $database);
                $_SESSION['message'] = "Your password has been successfully reset! Go back to <a href='login.php' class='forgot-password-link'>Login</a>";
            } else {
                $_SESSION['message'] = "Error updating password. Please try again.";
            }
        } else {
            $_SESSION['message'] = "Invalid or expired token!";
        }
    } else {
        $_SESSION['message'] = "Invalid role detected!";
    }
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/animations.css">  
    <link rel="stylesheet" href="css/main.css">  
    <link rel="stylesheet" href="css/login.css">
    <title>Reset Password</title>
</head>
<body>
    <center>
    <div class="container">
        <table border="0" style="margin: 0;padding: 0;width: 60%;">
            <tr>
                <td><p class="header-text">Reset Your Password</p></td>
            </tr>
        <div class="form-body">
            <tr>
                <td><p class="sub-text">Enter your new password below</p></td>
            </tr>
            <tr>
                <form method="POST" action="reset_password.php?token=<?php echo $_GET['token']; ?>&role=<?php echo $_GET['role']; ?>">
                <td class="label-td">
                    <label for="password" class="form-label">New Password: </label>
                </td>
            </tr>
            <tr>
                <td class="label-td">
                    <input type="password" name="password" class="input-text" placeholder="Enter new password" required>
                </td>
            </tr>
            <tr>
                <td><br><?php echo isset($_SESSION['message']) ? "<p class='error-message'>{$_SESSION['message']}</p>" : ""; ?></td>
            </tr>
            <tr>
                <td>
                    <input type="submit" value="Reset Password" class="login-btn btn-primary btn">
                </td>
            </tr>
        </div>
                </form>
        </table>
    </div>
    </center>
</body>
</html>

