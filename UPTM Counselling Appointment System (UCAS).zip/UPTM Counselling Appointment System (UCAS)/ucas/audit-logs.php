<?php
// Include database connection
include("connection.php");

function logAudit($email, $action, $database) {
    // Get the user's IP address
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // Prepare the SQL statement to insert into audit_logs
    $stmt = $database->prepare("INSERT INTO audit_logs (user_email, action, ip_address) VALUES (?, ?, ?)");
    
    if ($stmt) {
        // Bind parameters
        $stmt->bind_param("sss", $email, $action, $ip_address);
        
        // Execute statement
        $stmt->execute();
        
        // Close the statement
        $stmt->close();
    } else {
        // Handle errors (optional logging for debugging)
        error_log("Failed to prepare statement for audit logging.");
    }
}
?>
