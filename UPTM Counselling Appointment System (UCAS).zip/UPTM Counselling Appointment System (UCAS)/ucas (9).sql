-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2025 at 08:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ucas`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aemail` varchar(255) NOT NULL,
  `apassword` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aemail`, `apassword`) VALUES
('admin@ucas.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appoid` int(11) NOT NULL,
  `sid` int(10) DEFAULT NULL,
  `apponum` int(3) DEFAULT NULL,
  `scheduleid` int(10) DEFAULT NULL,
  `appodate` date DEFAULT NULL,
  `counselling_type` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Upcoming'
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appoid`, `sid`, `apponum`, `scheduleid`, `appodate`, `counselling_type`, `remarks`, `status`) VALUES
(12, 5, 1, 22, '2025-04-19', 'Kesihatan Mental', 'I feel so alone lately...', 'Upcoming'),
(5, 4, 1, 14, '2025-04-06', 'Lain-lain', 'I just someone to talk to', 'Completed'),
(9, 5, 1, 20, '2025-04-08', 'Kewangan', 'Need financial advices..', 'Completed'),
(10, 5, 1, 21, '2025-04-19', 'Pembelajaran', 'I feel like sometime i am so left behind compared to with my peers', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_email`, `action`, `ip_address`, `timestamp`) VALUES
(1, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-03 17:56:46'),
(2, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-03 18:02:03'),
(3, 'afznrimnina@gmail.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-03 18:03:53'),
(4, 'afnrimnina@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-03 18:04:20'),
(5, 'afnrimnina@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-03 18:04:27'),
(6, 'afnrimnina@gmail.com', 'Successful Login (Student)', '::1', '2025-04-03 18:15:04'),
(7, 'afznrimnina@gmail.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-03 18:15:29'),
(8, 'afnrimnina@gmail.com', 'Successful Login (Student)', '::1', '2025-04-03 18:16:02'),
(9, 'afznrimnina@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-03 18:20:32'),
(10, 'afznrimnina@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-03 18:20:50'),
(11, 'afnrimnina@gmail.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-03 18:21:12'),
(12, 'afznrimnina@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-03 18:21:19'),
(13, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-03 18:21:31'),
(14, 'afznrimnina@gmail.com', 'Successful Login (Student)', '::1', '2025-04-03 18:22:41'),
(15, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-03 18:24:47'),
(16, 'inozahirah@gmail.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-03 18:41:53'),
(17, 'inozahirah@gmail.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-03 18:42:10'),
(18, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-03 18:45:49'),
(19, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-03 18:46:02'),
(20, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-03 19:12:11'),
(21, 'norhayati23@gmail.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-03 19:14:06'),
(22, 'norhayati23@gmail.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-03 19:14:17'),
(23, 'norhayatiselamat23@gmail.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-03 19:14:40'),
(24, 'norhayatiselamat23@gmail.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-03 19:14:54'),
(25, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-03 19:15:20'),
(26, 'norhayatiselamat23@ucas.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-03 19:15:34'),
(27, 'norhayatiselamat23@gmail.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-03 19:15:52'),
(28, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-03 19:17:29'),
(29, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-03 19:18:38'),
(30, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-03 19:19:57'),
(31, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-03 19:31:36'),
(32, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-03 20:00:42'),
(33, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-03 20:04:04'),
(34, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-05 17:46:22'),
(35, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-05 23:04:52'),
(36, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-05 23:07:02'),
(37, 'norhayatiselamat23@gmail.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-06 00:06:02'),
(38, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-06 00:06:16'),
(39, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-06 00:09:18'),
(40, 'inozrh@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 14:07:10'),
(41, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 14:19:47'),
(42, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 14:22:13'),
(43, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 14:26:22'),
(44, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-06 15:42:40'),
(45, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-06 15:43:04'),
(46, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-06 15:43:15'),
(47, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 15:44:33'),
(48, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 15:50:10'),
(49, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:17:07'),
(51, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-06 16:18:14'),
(52, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-06 16:18:26'),
(53, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-06 16:20:06'),
(54, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-06 16:20:17'),
(55, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:22:39'),
(56, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:23:36'),
(57, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:23:46'),
(58, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:24:12'),
(59, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:25:06'),
(60, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:26:39'),
(62, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-06 16:28:31'),
(63, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-06 16:28:37'),
(64, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:28:55'),
(65, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:29:33'),
(67, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:38:30'),
(69, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-06 16:39:16'),
(70, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-06 16:39:22'),
(71, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-06 16:39:48'),
(72, 'afznrimnina@gmail.com', 'Successful Login (Student)', '::1', '2025-04-06 16:43:05'),
(73, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 16:56:14'),
(75, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-06 17:01:36'),
(77, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-06 17:03:46'),
(78, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-06 17:04:00'),
(79, 'counsellor@ucas.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-06 23:49:07'),
(80, 'counsellor@ucas.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-06 23:49:19'),
(81, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-06 23:49:49'),
(82, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-06 23:57:16'),
(83, 'counsellor@ucas.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-06 23:57:31'),
(84, 'counsellor@ucas.com', 'Failed Login Attempt (Invalid Credentials - Counsellor)', '::1', '2025-04-07 00:08:41'),
(85, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 00:08:56'),
(86, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 00:16:42'),
(87, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 00:17:39'),
(88, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 00:19:04'),
(89, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 00:24:27'),
(90, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 00:24:51'),
(91, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 00:39:22'),
(92, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 00:39:34'),
(93, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-07 00:42:06'),
(94, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 00:42:17'),
(95, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-07 00:46:00'),
(97, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 00:46:41'),
(98, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 01:32:03'),
(99, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 01:32:55'),
(100, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 01:48:31'),
(101, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 01:49:36'),
(102, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 02:00:42'),
(103, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 02:03:54'),
(104, 'counsellingcler@ucas.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-07 02:22:33'),
(105, 'cunsellingclerk@ucas.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-07 02:22:45'),
(106, 'counsellinclerk@ucas.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-07 02:22:58'),
(107, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 02:23:12'),
(108, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 02:28:12'),
(109, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-07 02:36:36'),
(110, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 02:42:31'),
(111, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 04:10:23'),
(112, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 12:10:54'),
(113, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 12:11:32'),
(114, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 12:17:07'),
(115, 'weiying@ucas.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 12:19:24'),
(116, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 12:20:04'),
(117, 'weiying@ucas.com', 'Updated counsellor (ID: 5): Email changed from weiying@ucas.com to weiying@ucas.com', '::1', '2025-04-07 12:39:13'),
(118, 'weiying@ucas.com', 'Updated counsellor (ID: 5): Email changed from weiying@ucas.com to weiying@ucas.com', '::1', '2025-04-07 12:39:55'),
(119, 'weiying@ucas.com', 'Updated counsellor (ID: 5): Data Updated', '::1', '2025-04-07 12:43:23'),
(120, 'weiying@ucas.com', NULL, '::1', '2025-04-07 12:43:23'),
(121, 'weiying@ucas.com', 'Updated counsellor (ID: 5): Data Updated \'Mr. Wei Ying\'', '::1', '2025-04-07 12:44:50'),
(122, 'nurina2806@gmail.com', 'Updated student (ID: 5): Data Updated \'Muhammad Zafran Zaim\'', '::1', '2025-04-07 12:46:37'),
(123, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-07 12:50:45'),
(125, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 12:52:54'),
(126, 'afznrimnina@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 13:12:08'),
(127, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 13:12:42'),
(128, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 13:21:18'),
(129, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-07 13:23:50'),
(130, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-07 13:25:13'),
(132, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-07 13:26:41'),
(133, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 13:26:53'),
(134, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-07 13:29:35'),
(135, 'c855ab1e', 'Password Reset Successful (s)', '::1', '2025-04-07 13:30:12'),
(136, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 13:30:25'),
(137, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 13:30:36'),
(138, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 13:34:23'),
(139, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 13:41:52'),
(140, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 13:44:00'),
(141, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 19:15:14'),
(142, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 19:15:49'),
(143, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 19:25:11'),
(144, 'counsellor@ucas.com', 'Updated counsellor (ID: 1): Data Updated \'Nurina Zahirah\', Password updated', '::1', '2025-04-07 19:25:27'),
(145, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-07 19:34:40'),
(146, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 20:41:44'),
(147, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-07 21:14:07'),
(148, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-07 23:24:31'),
(149, 'inozahirah@gmail.com', 'Updated counsellor (ID: 3): Data Updated \'Mrs. Wan Suriani Binti Wan Ibrahim\'', '::1', '2025-04-07 23:27:53'),
(150, 'sitiaaina246@gmail.com', 'Updated counsellor (ID: 10): Data Updated \'Miss Siti Ainaa Asilah Binti Abdul Razak\'', '::1', '2025-04-07 23:37:45'),
(151, 'afznrimnina@gmail.com', 'Updated student (ID: 4): Data Updated \'Afza Nur Imanina\'', '::1', '2025-04-07 23:51:31'),
(152, 'inozahirah@gmail.com', 'Updated counsellor (ID: 3): Data Updated \'Mrs. Wan Suriana Binti Wan Ibrahim\'', '::1', '2025-04-07 23:54:38'),
(153, 'counsellingclerk@gmail.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-07 23:55:57'),
(154, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 23:56:09'),
(155, 'counsellingclerk@ucas.com', 'Successful Login (Counselling Clerk)', '::1', '2025-04-07 23:59:49'),
(156, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-08 00:06:40'),
(157, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-08 00:11:52'),
(158, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-08 00:13:26'),
(159, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-08 02:18:55'),
(160, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-08 02:29:57'),
(161, 'inozahirah@ucas.com', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-08 03:10:09'),
(162, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-08 03:10:24'),
(163, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-08 03:43:11'),
(164, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-08 12:09:18'),
(165, 'student@ucas.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-08 12:12:06'),
(166, 'inozahirah@gmail.com', 'Password Reset Requested (c)', '::1', '2025-04-08 12:15:47'),
(167, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-08 12:20:10'),
(168, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-08 13:54:35'),
(169, 'acaef05e', 'Password Reset Successful (s)', '::1', '2025-04-08 13:54:54'),
(170, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-10 13:10:35'),
(171, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-19 02:01:28'),
(172, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-19 02:21:52'),
(173, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-19 02:41:20'),
(174, 'nurina2806@gmail.com', 'Failed Login Attempt (Invalid Credentials - Student)', '::1', '2025-04-19 02:57:18'),
(175, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-19 02:57:38'),
(176, 'kl2304013305@student.uptm.edu.my', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-19 03:04:13'),
(177, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-19 03:04:33'),
(178, 'afznrimnina@gmail.com', 'Updated student (ID: 4): Data Updated \'Afza Nur Imanina Binti Anuar\'', '::1', '2025-04-19 03:07:27'),
(179, 'kl2304013305@student.uptm.edu.my', 'Failed Login Attempt (Email Not Registered)', '::1', '2025-04-19 03:15:49'),
(180, 'kl230401330@student.uptm.edu.my', 'Successful Login (Student)', '::1', '2025-04-19 03:16:10'),
(181, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-19 12:45:56'),
(182, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-19 16:46:25'),
(183, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-19 16:49:57'),
(184, 'nurina2806@gmail.com', 'Updated student (ID: 5): Data Updated \'Muhammad Zafran Zaim\'', '::1', '2025-04-19 16:50:23'),
(185, 'kl2304013305@student.uptm.edu.my', 'Updated student (ID: 8): Data Updated \'Nurina Zahirah Binti Md Zamri\'', '::1', '2025-04-19 16:50:37'),
(186, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-19 16:51:04'),
(187, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-19 17:20:29'),
(188, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-19 17:29:41'),
(189, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-19 17:30:14'),
(190, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-19 17:39:51'),
(191, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-19 18:12:47'),
(192, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-19 20:34:18'),
(193, 'nurina2806@gmail.com', 'Password Reset Requested (s)', '::1', '2025-04-19 21:52:26'),
(194, 'af26dd8b', 'Password Reset Successful (s)', '::1', '2025-04-19 21:52:54'),
(195, 'nurina2806@gmail.com', 'Successful Login (Student)', '::1', '2025-04-19 22:11:21'),
(196, 'inozahirah@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-20 07:41:24'),
(197, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-20 07:42:00'),
(198, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-20 07:43:36'),
(199, 'laila@gmail.com', 'Updated counsellor (ID: 12): Data Updated \'Mrs. Laila\'', '::1', '2025-04-20 07:44:48'),
(200, 'afznrimnina@gmail.com', 'Updated student (ID: 4): Data Updated \'Afza Nur Imanina Binti Anuar\'', '::1', '2025-04-20 07:46:07'),
(201, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-20 07:49:25'),
(202, 'admin@ucas.com', 'Successful Login (Admin)', '::1', '2025-04-20 07:59:56'),
(203, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-20 08:13:51'),
(204, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-20 08:16:46'),
(205, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-20 08:20:30'),
(206, 'norhayatiselamat23@gmail.com', 'Successful Login (Counsellor)', '::1', '2025-04-20 08:22:13'),
(207, 'kl2304013305@student.uptm.edu.my', 'Successful Login (Student)', '::1', '2025-04-20 08:25:27');

-- --------------------------------------------------------

--
-- Table structure for table `clerk`
--

CREATE TABLE `clerk` (
  `remail` varchar(255) NOT NULL,
  `rpassword` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `clerk`
--

INSERT INTO `clerk` (`remail`, `rpassword`) VALUES
('counsellingclerk@ucas.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `counsellor`
--

CREATE TABLE `counsellor` (
  `cid` int(11) NOT NULL,
  `cemail` varchar(255) DEFAULT NULL,
  `cname` varchar(255) DEFAULT NULL,
  `cpassword` varchar(255) DEFAULT NULL,
  `cnic` varchar(15) DEFAULT NULL,
  `ctel` varchar(15) DEFAULT NULL,
  `position` int(2) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `counsellor`
--

INSERT INTO `counsellor` (`cid`, `cemail`, `cname`, `cpassword`, `cnic`, `ctel`, `position`, `token`, `token_expiry`) VALUES
(4, 'norhayatiselamat23@gmail.com', 'Mrs. Nor Hayati', '$2y$10$UypZeygnOwwVB9USmFnHE.NwUzeZZ.aemGMHymlphbc6lDQbzQd.6', '690618061996', '0182587745', 1, NULL, NULL),
(3, 'inozahirah@gmail.com', 'Mrs. Wan Suriana Binti Wan Ibrahim', '$2y$10$Bs8Nh1jhi9m.sDD2DKP53.EmFaH2DbwTuqdGs.Xr2Fo5nzugSk6VS', '880715-03-5678', '0148298761', 1, 'be75dae99bbe57ec5167dfcf39c86e898f4d6bb3f6d93ab489e4e1c520884789a55ce2c58f3e42675439e4d33ad17d7667a6', '2025-04-08 13:15:45'),
(7, 'nikmazlina@uptm.edu.my', 'Mrs. Nik Mazlinahaiza Binti Abdullah', '$2y$10$it8qy5dNOo7tt31hQC/tKeJDpY9Y2kfzIr9fhSjapkjcRgf2sg9da', '880312-14-2345', '0162363841', 1, NULL, NULL),
(8, 'zalina_z@uptm.edu.my', 'Miss Nor Zalina Binti Zalwadi', '$2y$10$i3RBfbJmNthNuukFFnu9B.4KakgHl/40hNDRtStb5Gc9e.vdYeoXC', '890624-08-3456', '01282587745', 1, NULL, NULL),
(9, 'mukramin_1@uptm.edu.my', 'Mr. Mohammad Mukramin Bin Samrah', '$2y$10$MA7NB/fkDuEcsvjKlgiHI.RWxAbjXzNlpGNnvB4yVmQeqnUsKXnl2', '921104-05-4321', '0182638374', 1, NULL, NULL),
(10, 'sitiaaina246@gmail.com', 'Miss Siti Ainaa Asilah Binti Abdul Razak', '$2y$10$9/txpXktWE0N8MUvsT9h8uS9q.uLpSDQpQ9hIyzXfrZq006vNDFiy', '990825-14-3456', '01121193757', 2, NULL, NULL),
(11, 'h2razali123@gmail.com', 'Mr. Muhammad Haris Bin Razali', '$2y$10$q.YgAViGDa4lRxlhbVtDkeGjmFh3RG6Qj0o3g61Ta91flyDVxjch.', '980412-06-7890', '0133336450', 2, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `id` int(2) NOT NULL,
  `pname` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`id`, `pname`) VALUES
(1, 'Kaunselor'),
(2, 'Kaunselor Pelatih');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `scheduleid` int(11) NOT NULL,
  `cid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `scheduledate` date DEFAULT NULL,
  `scheduletime` time DEFAULT NULL,
  `max_pax` int(11) DEFAULT 1
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`scheduleid`, `cid`, `title`, `scheduledate`, `scheduletime`, `max_pax`) VALUES
(18, '4', 'INDIVIDUAL', '2025-04-08', '12:00:00', 1),
(9, '2', 'INDIVIDUAL', '2025-04-04', '09:00:00', 1),
(12, '3', 'INDIVIDUAL', '2025-04-04', '09:00:00', 1),
(13, '4', 'INDIVIDUAL', '2025-04-04', '09:00:00', 1),
(14, '4', 'INDIVIDUAL', '2025-04-07', '09:00:00', 1),
(15, '4', 'INDIVIDUAL', '2025-04-07', '14:00:00', 1),
(17, '3', 'INDIVIDUAL', '2025-04-07', '09:00:00', 1),
(20, '3', 'INDIVIDUAL', '2025-04-08', '14:00:00', 1),
(21, '4', 'GROUP ', '2025-04-21', '09:00:00', 2),
(22, '3', 'INDIVIDUAL', '2025-04-21', '14:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` int(11) NOT NULL,
  `semail` varchar(255) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `spassword` varchar(255) DEFAULT NULL,
  `studid` varchar(15) DEFAULT NULL,
  `scode` varchar(10) DEFAULT NULL,
  `stel` varchar(15) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `semail`, `sname`, `spassword`, `studid`, `scode`, `stel`, `token`, `token_expiry`) VALUES
(8, 'kl2304013305@student.uptm.edu.my', 'Nurina Zahirah Binti Md Zamri', '$2y$10$LG4p3eAd6GHjLorfKUBkRedAuniyR0QjkfqYofoBwdRS.Az7A5I3e', 'AM2304013305', 'CT206', '01116374480', NULL, NULL),
(4, 'afznrimnina@gmail.com', 'Afza Nur Imanina Binti Anuar', '$2y$10$Wa7I/.Rr4r/FS2byPoIyyeylHoW/HhdHSILaC9N/XC44t.fLEUKBS', 'AM2304013316', 'BK201', '0192739283', NULL, NULL),
(5, 'nurina2806@gmail.com', 'Muhammad Zafran Zaim', '$2y$10$sqlfdgesBbmYZ2mNzhfrHOiEfczsU/.izxicpT3RDjLMhR0owRpQa', 'AM2304013307', 'CT206', '0111624716', NULL, NULL),
(6, 'kl2304013537@student.uptm.edu.my', 'Nuralya Atiqah Binti Yusri', '$2y$10$7R8dltVyUaYoIewrhe/G/ee6aHRZmPPrVXnzHQy3zFEvrpuLYKnyu', 'AM2304013537', 'CT206', '0182283291', NULL, NULL),
(7, 'kl2304013771@student.uptm.edu.my', 'Nurin Addina Jaida Binti Mohd Jafri', '$2y$10$1TLmDIjihwMa9GwBbp8JsuXYc.rfRkHrPuiCsVGBrhtadl7W1BwyO', 'AM2304013771', 'CT206', '0192381991', NULL, NULL),
(9, 'kl2304013007@student.uptm.edu.my', 'Muhammad Harith Irfan Bin Shariffudin', '$2y$10$3Z5CNTF//sLcNpSB5e33sOW2WJUrpo1zkCIuRwOrh.jOeWSA88FqK', 'AM2304013007', 'BK201', '0131123002', NULL, NULL),
(10, 'kl2304014001@student.uptm.edu.my', 'Rose Farhana Shafiah Binti Noornikmandadamiah', '$2y$10$iliqxd.zMFn8MbzRbVPF1.xeYOXNr1tJo4gIQRTqh4tB.Cj.ceM02', 'AM2304014001', 'AA201', '0197435682', NULL, NULL),
(11, 'kl2304013772@student.uptm.edu.my', 'Muhammad Shukri Bin Ramlan', '$2y$10$IIwRIKpShQQXy/W9V/3ff.lqh6nPNPD2uE/t99Kvs7F8WdgLML8W.', 'AM2304013772', 'CT204', '0162738821', NULL, NULL),
(12, 'kl2304013303@student.uptm.edu.my', 'Izzati Aina Aliah Binti Rosli', '$2y$10$y5gjSm870KMjyBtao.kwRuT8f8J7a2.4VcgnLe8T6eY2Z5xG1gPea', 'AM2304013303', 'CT203', '0192773420', NULL, NULL),
(13, 'kl2304015440@student.uptm.edu.my', 'Loqman Hakim Bin Razak', '$2y$10$msIoQAKK4J5LkfKjeeQcj.J5sXB/nwzwy6jPWsmLYVAGnRxjbAqLm', 'AM2304015440', 'BK201', '0182931192', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `webuser`
--

CREATE TABLE `webuser` (
  `email` varchar(255) NOT NULL,
  `usertype` char(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `webuser`
--

INSERT INTO `webuser` (`email`, `usertype`) VALUES
('admin@ucas.com', 'a'),
('kl2304013771@student.uptm.edu.my', 's'),
('kl2304013305@student.uptm.edu.my', 's'),
('inozrh@gmail.com', 's'),
('norhayatiselamat23@gmail.com', 'c'),
('afznrimnina@gmail.com', 's'),
('inozahirah@gmail.com', 'c'),
('nurina2806@gmail.com', 's'),
('counsellingclerk@ucas.com', 'r'),
('nikmazlina@uptm.edu.my', 'c'),
('zalina_z@uptm.edu.my', 'c'),
('mukramin_1@uptm.edu.my', 'c'),
('sitiaaina246@gmail.com', 'c'),
('h2razali123@gmail.com', 'c'),
('kl2304013537@student.uptm.edu.my', 's'),
('kl2304013007@student.uptm.edu.my', 's'),
('kl2304014001@student.uptm.edu.my', 's'),
('kl2304013772@student.uptm.edu.my', 's'),
('kl2304013303@student.uptm.edu.my', 's'),
('kl2304015440@student.uptm.edu.my', 's');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aemail`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appoid`),
  ADD KEY `sid` (`sid`),
  ADD KEY `scheduleid` (`scheduleid`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clerk`
--
ALTER TABLE `clerk`
  ADD PRIMARY KEY (`remail`);

--
-- Indexes for table `counsellor`
--
ALTER TABLE `counsellor`
  ADD PRIMARY KEY (`cid`),
  ADD KEY `position` (`position`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`scheduleid`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `webuser`
--
ALTER TABLE `webuser`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `counsellor`
--
ALTER TABLE `counsellor`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `scheduleid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
